#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
 /**
 * @Description:
 * @author: quaint
 * @Date: Created in ${DATE} ${TIME}
 */
public class ${NAME} {
}
